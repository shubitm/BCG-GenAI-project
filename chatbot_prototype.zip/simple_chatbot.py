
def simple_chatbot(user_query):
    # Define predefined queries and responses
    if user_query == "What is the total revenue?":
        return "The total revenue is $100 million."
    elif user_query == "How has net income changed over the last year?":
        return "The net income has increased by 5% over the last year."
    elif user_query == "What are the total assets of the company?":
        return "The total assets are $250 million."
    elif user_query == "What are the total liabilities of the company?":
        return "The total liabilities are $150 million."
    elif user_query == "What is the cash flow from operating activities?":
        return "The cash flow from operating activities is $30 million."
    else:
        return "Sorry, I can only provide information on predefined queries."

# Test chatbot
user_input = input("Ask a financial question: ")
response = simple_chatbot(user_input)
print(response)
